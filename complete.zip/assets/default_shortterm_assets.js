const default_shortterm_assets = `group,Cash,Investments,A/R
Jan,30,12,2
Feb,40,11,1
Mar,50,11,3
Apr,25,12,4
May,26,12,2
Jun,36,13,1
Jul,24,14,2
Aug,43,11,3
Sep,23,12,4
Oct,13,13,2
Nov,34,14,1
Dec,45,15,2`
