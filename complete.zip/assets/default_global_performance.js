const default_global_performance = `group,Cash-to-Cash Cycle Time,Account Rec. Days,Inventory Days,Accounts Payable Days
NA,-20,12,17,20
EUR,5,18,18,24
Asia,15,25,19,25
SA,25,40,25,28`;
