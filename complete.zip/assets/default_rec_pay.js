const default_rec_pay = `group,Accounts Receivable,Accounts Payable
Current,24900,12400
First,23000,11600
Second,10000,8640
Third,7000,79450
Fourth,4000,46920`;